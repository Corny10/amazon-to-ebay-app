
import { useState } from "react";

export default function App() {
  const [url, setUrl] = useState("");
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const fetchProduct = async () => {
    setLoading(true);
    setProduct(null);

    const dummyProduct = {
      title: "JBL Tune 510BT",
      price: 39.99,
      image: "https://m.media-amazon.com/images/I/71urmj1N+dL._AC_SL1500_.jpg",
      description: `✅ Original JBL Sound\n✅ Kabellos\n✅ 40h Akkulaufzeit`,
    };

    setTimeout(() => {
      setProduct(dummyProduct);
      setLoading(false);
    }, 1000);
  };

  return (
    <div style={{ padding: 20, maxWidth: 500, margin: "auto" }}>
      <h1>Amazon → eBay Tool</h1>
      <input
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="Amazon-Link einfügen"
        style={{ width: "100%", marginBottom: 10 }}
      />
      <button onClick={fetchProduct}>
        {loading ? "Lädt..." : "Produkt abrufen"}
      </button>
      {product && (
        <div style={{ marginTop: 20 }}>
          <img src={product.image} style={{ width: "100%" }} />
          <h2>{product.title}</h2>
          <p>Amazon: €{product.price}</p>
          <p>eBay: €{(product.price * 2).toFixed(2)}</p>
          <pre>{product.description}</pre>
        </div>
      )}
    </div>
  );
}
