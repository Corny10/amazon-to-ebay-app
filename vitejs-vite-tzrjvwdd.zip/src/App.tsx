import { useState } from "react";

export default function App() {
  const [url, setUrl] = useState("");
    const [product, setProduct] = useState<any>(null);
      const [loading, setLoading] = useState(false);

        const fetchProduct = async () => {
            setLoading(true);
                setProduct(null);

                    // Dummy-Daten (später durch echte Amazon-Daten ersetzen)
                        const dummyProduct = {
                              title: "JBL Tune 510BT – Kabellose On-Ear Kopfhörer",
                                    price: 39.99,
                                          image: "https://m.media-amazon.com/images/I/71urmj1N+dL._AC_SL1500_.jpg",
                                                description: `✅ Original JBL Sound\n✅ Kabellos über Bluetooth\n✅ Bis zu 40h Akkulaufzeit\n✅ Inkl. USB-C Ladekabel\n🔄 30 Tage Rückgaberecht`,
                                                    };

                                                        setTimeout(() => {
                                                              setProduct(dummyProduct);
                                                                    setLoading(false);
                                                                        }, 1000);
                                                                          };

                                                                            return (
                                                                                <div style={{ maxWidth: "500px", margin: "auto", padding: "1rem" }}>
                                                                                      <h1 style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>
                                                                                              Amazon → eBay Tool
                                                                                                    </h1>

                                                                                                          <input
                                                                                                                  type="text"
                                                                                                                          placeholder="Amazon-Link hier einfügen"
                                                                                                                                  value={url}
                                                                                                                                          onChange={(e) => setUrl(e.target.value)}
                                                                                                                                                  style={{ width: "100%", padding: "0.5rem", margin: "1rem 0" }}
                                                                                                                                                        />

                                                                                                                                                              <button onClick={fetchProduct} disabled={!url || loading}>
                                                                                                                                                                      {loading ? "Lädt..." : "Produkt abrufen"}
                                                                                                                                                                            </button>

                                                                                                                                                                                  {product && (
                                                                                                                                                                                          <div style={{ marginTop: "1rem", border: "1px solid #ccc", padding: "1rem", borderRadius: "10px" }}>
                                                                                                                                                                                                    <img src={product.image} alt="Produkt" style={{ width: "100%", borderRadius: "10px" }} />
                                                                                                                                                                                                              <h2 style={{ fontSize: "1.2rem", fontWeight: "bold" }}>{product.title}</h2>
                                                                                                                                                                                                                        <p>Amazon-Preis: €{product.price.toFixed(2)}</p>
                                                                                                                                                                                                                                  <p style={{ color: "green", fontWeight: "bold" }}>
                                                                                                                                                                                                                                              eBay-Preis: €{(product.price * 2).toFixed(2)}
                                                                                                                                                                                                                                                        </p>
                                                                                                                                                                                                                                                                  <pre style={{ backgroundColor: "#f4f4f4", padding: "0.5rem", whiteSpace: "pre-wrap" }}>
                                                                                                                                                                                                                                                                              {product.description}
                                                                                                                                                                                                                                                                                        </pre>
                                                                                                                                                                                                                                                                                                  <button
                                                                                                                                                                                                                                                                                                              onClick={() => {
                                                                                                                                                                                                                                                                                                                            navigator.clipboard.writeText(
                                                                                                                                                                                                                                                                                                                                            `Titel: ${product.title}\n\nPreis: €${(product.price * 2).toFixed(2)}\n\n${product.description}`
                                                                                                                                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                                                                                                                                                      }}
                                                                                                                                                                                                                                                                                                                                                                                >
                                                                                                                                                                                                                                                                                                                                                                                            📋 Beschreibung kopieren
                                                                                                                                                                                                                                                                                                                                                                                                      </button>
                                                                                                                                                                                                                                                                                                                                                                                                              </div>
                                                                                                                                                                                                                                                                                                                                                                                                                    )}
                                                                                                                                                                                                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                                                                                                                                                                                                          }